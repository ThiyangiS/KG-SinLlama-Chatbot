"""Optional SinLlama generation and exact-quote verification."""

import re
from dataclasses import dataclass

from .config import SINLLAMA_MODEL
from .prompting import build_prompt


def _normalize_quote(text):
    return re.sub(r'[\u200b\u200c\u200d\ufeff]', '', str(text or '')).casefold()


def repetitive_output(text):
    """Flag notebook-defined length, format and repetition failures."""
    if any(label in text for label in ("Question:", "\nප්‍රශ්නය:")):
        return True
    text = " ".join(text.split())
    if not text or len(text) > 4000:
        return True
    words = text.split()
    if len(words) > 12:
        grams = [" ".join(words[i:i + 5]) for i in range(len(words) - 4)]
        if len(set(grams)) / len(grams) < 0.72:
            return True
    return False


def _quote_pieces(text):
    parts = re.split(r"\s*\[…]\s*|(?<=[.!?।])\s+|\n+", text)
    return [part for raw in parts if (part := raw.strip(" \n\t-•"))]


def strict_quote_verification(candidate, evidence, *, require_complete=False):
    """Check exact source membership and optionally complete, ordered coverage."""
    if repetitive_output(candidate):
        return False, "repetition_or_bad_format"
    pieces = _quote_pieces(candidate)
    if not pieces:
        return False, "empty"
    expected = list(dict.fromkeys(
        _normalize_quote(piece).strip()
        for row in evidence
        for piece in _quote_pieces(row["source_quote"])
    ))
    actual = [_normalize_quote(piece).strip() for piece in pieces]
    if set(actual) - set(expected):
        return False, "not_an_exact_selected_source_sentence"
    if require_complete and set(expected) - set(actual):
        return False, "missing_selected_evidence"
    if require_complete and actual != expected:
        return False, "reordered_or_repeated_source_sentences"
    return True, "exact_source_quotes_only"


@dataclass(frozen=True)
class GenerationConfig:
    max_new_tokens: int = 512
    max_input_tokens: int = 3000


class SinLlamaGenerator:
    """Load SinLlama lazily via CUDA 4-bit inference, using the cache by default."""

    def __init__(self, model_id=SINLLAMA_MODEL, config=None, *, local_files_only=True):
        self.model_id = model_id
        self.config = config or GenerationConfig()
        self.local_files_only = local_files_only
        self._load_error = None
        self._model = None
        self._tokenizer = None

    def _load(self, torch):
        if not torch.cuda.is_available():
            raise RuntimeError("The 4-bit SinLlama loader requires a suitable CUDA GPU.")
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

        quantization = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.float16,
        )
        tokenizer = AutoTokenizer.from_pretrained(self.model_id, local_files_only=self.local_files_only)
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        model = AutoModelForCausalLM.from_pretrained(
            self.model_id,
            quantization_config=quantization,
            device_map="auto",
            low_cpu_mem_usage=True,
            local_files_only=self.local_files_only,
            use_safetensors=True,
        )
        self._tokenizer, self._model = tokenizer, model.eval()

    def propose(self, question, sources):
        """Generate a candidate from the selected source excerpts."""
        import torch

        if self._load_error is not None:
            raise self._load_error
        if self._model is None:
            try:
                self._load(torch)
            except (ImportError, OSError, RuntimeError, ValueError) as exc:
                # Avoid reattempting a failed model download/load for every question.
                self._load_error = exc
                raise
        tokenizer, model, config = self._tokenizer, self._model, self.config
        inputs = tokenizer(
            build_prompt(question, sources),
            return_tensors="pt",
        )
        if inputs["input_ids"].shape[-1] > config.max_input_tokens:
            raise ValueError("Evidence prompt exceeds the input budget.")
        device = model.get_input_embeddings().weight.device
        inputs = {name: tensor.to(device) for name, tensor in inputs.items()}
        with torch.inference_mode():
            output = model.generate(
                **inputs,
                max_new_tokens=config.max_new_tokens,
                do_sample=False,
                stop_strings=["\nQuestion:", "\nSources:", "\nප්‍රශ්නය:", "\nමූලාශ්‍ර:"],
                tokenizer=tokenizer,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        new_tokens = output[0][inputs["input_ids"].shape[-1]:]
        candidate = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
        return re.split(
            r"\n\s*(?:Question|Sources?|ප්‍රශ්නය|මූලාශ්‍ර)\s*:", candidate,
            maxsplit=1, flags=re.IGNORECASE,
        )[0].strip()


def apply_generation(question, result, generator):
    """Accept complete ordered source copies or preserve the local answer."""
    fallback = result["answer"]
    audit = {
        **result,
        "extractive_fallback": fallback,
        "model_generated_answer": None,
        "generation_status": "GENERATION_SKIPPED",
        "verification_reason": "not_run",
        "fallback_reason": result["status"],
        "final_answer": fallback,
    }
    if result["status"] not in (
        "SOURCE_GROUNDED_EXTRACTIVE", "SOURCE_GROUNDED_FACT_EXTRACTED"
    ) or not result["sources"]:
        return audit
    try:
        candidate = generator.propose(question, result["sources"])
    except (ImportError, OSError, RuntimeError, ValueError) as exc:
        return {
            **audit,
            "generation_status": "EXTRACTIVE_FALLBACK_GENERATION_ERROR",
            "fallback_reason": f"generation_error:{type(exc).__name__}",
        }
    passed, reason = strict_quote_verification(candidate, result["sources"], require_complete=True)
    answer = candidate if passed else fallback
    return {
        **audit,
        "answer": answer,
        "final_answer": answer,
        "model_generated_answer": candidate,
        "generation_status": (
            "GENERATED_EXACT_SOURCE_QUOTE_REVIEW_REQUIRED"
            if passed else "EXTRACTIVE_FALLBACK_NOT_VERIFIED"
        ),
        "verification_reason": reason,
        "fallback_reason": None if passed else reason,
    }
