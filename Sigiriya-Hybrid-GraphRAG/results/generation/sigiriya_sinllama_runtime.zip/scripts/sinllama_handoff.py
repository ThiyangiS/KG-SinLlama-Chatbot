"""Export local evidence and run the same generation verifier in Colab."""

import argparse
import json
import os
from dataclasses import asdict
from pathlib import Path
from zipfile import ZipFile

from src.config import PROJECT_DIR
from src.generation import _quote_pieces, apply_generation


SCHEMA_VERSION = 1
DEMO_QUESTIONS = (
    ("factual", "සීගිරි බිතුසිතුවම්වල කාන්තා රූප ලෙස නිරූපණය කර ඇත්තේ කවුරුන්ද?"),
    ("overview", "සීගිරි බිතුසිතුවම් ගැන කියන්න."),
    ("multi_topic", "සීගිරි බිතුසිතුවම් සහ කැටපත් පවුර ගැන කියන්න."),
    ("multi_hop_route", "කොළඹ සිට දඹුල්ල හරහා සීගිරියට යන ගමන් මාර්ගය පැහැදිලි කරන්න."),
    ("mechanism", "දිය උල්පත් ක්‍රියාත්මක වන ආකාරය විස්තර කරන්න."),
    ("paraphrase", "පර්වතයේ බටහිර මුහුණතේ තිබූ චිත්‍ර ගැන කියන්න."),
    ("reason", "සීගිරිය නැරඹීමට උදෑසන පැමිණීම සුදුසු වන්නේ ඇයි?"),
    ("unsupported_person", "සීගිරි බිතුසිතුවම් ඇඳපු චිත්‍ර ශිල්පියා කවුද?"),
    ("live_data", "අද සීගිරියේ ප්‍රවේශපත්‍ර මිල කීයද?"),
)
RUNTIME_FILES = (
    "src/__init__.py", "src/config.py", "src/generation.py", "src/prompting.py",
    "scripts/sinllama_handoff.py",
)


def export_evidence(chatbot, questions):
    """Use the active local chatbot and keep only its selected citation text."""
    rows = []
    for question_id, question in questions:
        result = chatbot.answer(question)
        sources = result["sources"]
        for row in sources:
            stored = chatbot.retriever.sources[row["chunk_id"]]["evidence"]
            pieces = _quote_pieces(row["source_quote"])
            if not pieces or any(piece not in stored for piece in pieces):
                raise ValueError(f"{question_id}: selected quote is not traceable to its chunk.")
        selected = {row["chunk_id"] for row in sources}
        paths = [
            path for path in (result.get("retrieval") or {}).get("graph_paths", [])
            if path["edges"] and all(
                edge["chunk_id"] in selected and edge.get("fact_id") and edge.get("quote")
                and edge["quote"] in chatbot.retriever.sources[edge["chunk_id"]]["evidence"]
                for edge in path["edges"]
            )
        ]
        rows.append({
            "id": question_id, "question": result["question"], "status": result["status"],
            "reason": result["reason"], "subquestions": result["subquestions"],
            "extractive_fallback": result["answer"], "sources": sources,
            "graph_paths": paths,
        })
    return {"schema_version": SCHEMA_VERSION, "kind": "sigiriya_evidence", "questions": rows}


def generate_batch(payload, generator):
    """Generate from selected excerpts only and keep the decision for every question."""
    if payload.get("schema_version") != SCHEMA_VERSION or payload.get("kind") != "sigiriya_evidence":
        raise ValueError("Expected a version 1 Sigiriya evidence export.")
    results = []
    for row in payload["questions"]:
        result = {**row, "answer": row["extractive_fallback"]}
        results.append(apply_generation(row["question"], result, generator))
    return {
        "schema_version": SCHEMA_VERSION,
        "kind": "sigiriya_generation_results",
        "model_id": generator.model_id,
        "generation_config": asdict(generator.config),
        "results": results,
    }


def write_json(path, payload):
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_handoff(output, payload):
    """Write the UTF-8 evidence and the small runtime needed on Colab."""
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "sigiriya_sinllama_evidence.json", payload)
    with ZipFile(output / "sigiriya_sinllama_runtime.zip", "w") as archive:
        for name in RUNTIME_FILES:
            archive.write(PROJECT_DIR / name, name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=PROJECT_DIR / "results" / "generation")
    parser.add_argument("--questions", type=Path, help="Optional UTF-8 file, one question per line.")
    args = parser.parse_args()
    if not os.getenv("NEO4J_PASSWORD"):
        parser.error("Set NEO4J_PASSWORD in the local shell before exporting evidence.")
    if args.questions:
        lines = args.questions.read_text(encoding="utf-8-sig").splitlines()
        questions = [(f"Q{index:02d}", q.strip()) for index, q in enumerate(lines, 1) if q.strip()]
        if not questions:
            parser.error("The questions file must contain at least one nonempty line.")
    else:
        questions = DEMO_QUESTIONS

    from src.chatbot import SigiriyaChatbot
    from src.embeddings import E5Embeddings
    from src.graph import connect
    from src.retrieval import SigiriyaRetriever

    with connect() as session:
        chatbot = SigiriyaChatbot(SigiriyaRetriever(session, E5Embeddings(device="cpu")))
        payload = export_evidence(chatbot, questions)
    write_handoff(args.output, payload)
    print(f"Exported {len(questions)} questions and the Colab runtime to {args.output}")


if __name__ == "__main__":
    main()
