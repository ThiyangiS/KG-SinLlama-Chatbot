"""Sinhala prompts and fallback messages for source-grounded answers."""


NO_SOURCE_SI = (
    "ලබාදී ඇති සීගිරිය ලේඛනයෙන් මෙම ප්‍රශ්නයට අවශ්‍ය "
    "නිශ්චිත පිළිතුර තහවුරු කළ නොහැක."
)


NO_LIVE_SI = (
    "මෙම ප්‍රශ්නයට අවශ්‍ය යාවත්කාලීන තොරතුරු "
    "සීගිරිය පිළිබඳ ගබඩා කළ ලේඛනයෙන් තහවුරු කළ නොහැක. "
    "විශ්වාසදායක නවතම මූලාශ්‍රයක් බලන්න."
)


def build_evidence_context(sources, max_chars_each=600):
    """Format up to six selected quotes with their chunk IDs and headings."""
    lines = []
    seen = set()
    for row in sources[:6]:
        key = (row["chunk_id"], row["source_quote"])
        if key not in seen:
            seen.add(key)
            lines.append(f"[{key[0]}] {row['heading']}\n{key[1][:max_chars_each]}")
    return "\n\n".join(lines)


FEW_SHOT_EXAMPLE = (
    "[Illustrative example — separate from the current question]\n"
    "Sources: පෙට්ටියේ රතු බෝලයක් ඇත.\n"
    "Question: පෙට්ටියේ ඇත්තේ කුමක්ද?\n"
    "Answer: පෙට්ටියේ රතු බෝලයක් ඇත.\n"
    "[End example — use only the following sources]\n"
)


PROMPT_FORMATS = {
    "source_qa": ("", "Sources", "Question", "Answer"),
    "sinhala_qa": ("", "මූලාශ්‍ර", "ප්‍රශ්නය", "පිළිතුර"),
    "short_grounding": (
        "Answer in Sinhala using the source sentences in order.",
        "Sources", "Question", "Answer",
    ),
    "few_shot": (FEW_SHOT_EXAMPLE.rstrip(), "Sources", "Question", "Answer"),
}


def build_prompt(question, sources, *, variant="source_qa"):
    """Build a short base-model completion prompt with the full selected evidence."""
    instruction, source_label, question_label, answer_label = PROMPT_FORMATS[variant]
    context = build_evidence_context(sources, max_chars_each=None)
    prefix = f"{instruction}\n" if instruction else ""
    return f"{prefix}{source_label}:\n{context}\n\n{question_label}: {question}\n{answer_label}:"
